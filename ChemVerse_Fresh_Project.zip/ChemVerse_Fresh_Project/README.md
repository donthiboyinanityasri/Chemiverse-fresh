# ChemVerse – Chemistry Learning Lab

A fresh, standalone Streamlit chemistry learning app.

## Features
- Home and getting-started guide
- Beginner-friendly chemistry theory
- Searchable list of 118 elements
- Molecule information for common compounds
- Browser-based molecular motion illustration
- Embedded educational animation videos
- Chemistry quiz with score and explanations
- Practice assignments with downloadable answers
- Molecule comparison

## Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy with Streamlit Community Cloud
1. Create a **new GitHub repository** named `ChemVerse-Fresh`.
2. Upload `app.py`, `requirements.txt`, and `README.md` from this folder.
3. On Streamlit Community Cloud, choose **New app**.
4. Select the new repository, branch `main`, and main file path `app.py`.
5. Deploy.

This project is separate from the older Chemiverse- repository. You do not need to edit or replace files in the old repository.
